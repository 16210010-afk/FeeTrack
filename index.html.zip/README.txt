FeeTrack - Megapro Computers

1. Open FeeTrack.html in Chrome or another modern browser.
2. Student records are currently saved in this browser/device using local storage.
3. SMS buttons open the device's SMS composer with a prepared message.
4. For the same records on multiple phones/computers, the next step is to connect FeeTrack to an online database and host it online.
